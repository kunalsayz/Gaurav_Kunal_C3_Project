import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

public class Restaurant {
    private String name;
    private String location;
    public LocalTime openingTime;
    public LocalTime closingTime;
    private List<Item> menu = new ArrayList();


    Item findItemByName(String itemName) {
        for (Item item : menu) {
            if (item.getName().equals(itemName))
                return item;
        }
        return null;
    }
    

    public int getTotalCostOfItems(List<Item> selectedItems) {
        int totalCost = 0;
        for(Item item: selectedItems) {
            totalCost = totalCost + item.getPrice();
        }
        return  totalCost;
    }
}
